import { templateConfig as site } from "../../config/template.config";
import logo from "../../assets/logo.png";

export function Footer() {
  return <footer><div className="container footer-main"><div className="footer-brand"><img className="footer-brand-logo" src={logo} alt="Logo" /><strong>{site.brand.name.toUpperCase()}</strong><span>{site.brand.descriptor.toUpperCase()} · {site.brand.oab}</span></div><p>Estratégia jurídica, clareza e confiança<br />para decisões que importam.</p><div><a href="#inicio">Início</a><a href="#atuacao">Áreas de atuação</a><a href="#duvidas">Dúvidas frequentes</a><a href="#localizacao">Localização</a></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} {site.brand.name}.</span><span>Este material tem caráter meramente informativo e não constitui publicidade profissional nos termos do Provimento nº 205/2021 do CFOAB. As informações aqui veiculadas não garantem resultados específicos.</span></div><a className="developed-by" href="https://somos4juris.com.br/" target="_blank" rel="noopener noreferrer">Desenvolvido por 4Juris</a></footer>;
}
