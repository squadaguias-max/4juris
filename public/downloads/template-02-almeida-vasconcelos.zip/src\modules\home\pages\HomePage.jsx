import { createElement } from "react";
import { ArrowRight, BriefcaseBusiness, Building2, ChevronRight, Clock3, FileText, Landmark, Mail, MapPin, MessageCircle, Phone, Scale, ShieldCheck, Users } from "lucide-react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const icons = { building: Building2, scale: Scale, users: Users, briefcase: BriefcaseBusiness, landmark: Landmark, file: FileText };

export function HomePage() {
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(site.office.mapsQuery)}`;
  const mapsEmbed = `https://www.google.com/maps?q=${encodeURIComponent(site.office.mapsQuery)}&output=embed`;
  return <>
    <section className="hero" id="inicio"><div className="hero-shade" /><div className="container hero-content"><span className="eyebrow light">{site.brand.eyebrow}</span><h1>{site.brand.headline}<br /><em>{site.brand.headlineAccent}</em></h1><p>{site.brand.description}</p><div className="hero-actions pb-12"><a className="button" href={whatsappUrl()} target="_blank" rel="noreferrer">Conversar no WhatsApp <MessageCircle size={17} /></a><a href="#experiencia">Conheça o escritório</a></div></div>
    </section>

    <section className="experience-section container" id="experiencia">
      <div className="experience-visual">
        <div className="office-photo" role="img" aria-label="Reunião em um escritório de advocacia" />
        <div className="availability"><Clock3 /><span><b>24/7</b><small>Recebemos sua mensagem<br />a qualquer hora.</small></span></div>
      </div>
      <div className="experience-content">
        <div className="experience-copy"><span className="eyebrow">SOBRE O ESCRITÓRIO</span><h2>Nossa ampla <em>experiência jurídica</em></h2><p>{site.office.description}</p><div className="mini-features"><span><Building2 /> Atuação estratégica</span><span><ShieldCheck /> Soluções seguras</span></div></div>
        <div className="metrics">{site.metrics.map(item => <div key={item.label}><strong>{item.value}</strong><span>{item.label}</span></div>)}</div>
        <div className="experience-actions"><div className="editorial-card"><small>ATENDIMENTO</small><strong>Clareza desde a primeira conversa.</strong><a href={whatsappUrl()} target="_blank" rel="noreferrer">Iniciar conversa <ChevronRight /></a></div><a className="wide-link" href="#equipe">Conheça nossos advogados <ArrowRight /></a></div>
      </div>
    </section>

    <section className="practices compact-practices" id="atuacao"><div className="container"><div className="section-title"><div><span className="eyebrow">ÁREAS DE ATUAÇÃO</span><h2>Atuação <em>especializada.</em></h2></div><p>Soluções jurídicas para pessoas, famílias e empresas.</p></div><div className="practice-grid compact">{site.specialties.map((area, index) => { const Icon = icons[area.icon] || Scale; return <article key={area.title}><span>0{index + 1}</span>{createElement(Icon)}<div><h3>{area.title}</h3><p>{area.summary}</p><a href={whatsappUrl(area.message)} target="_blank" rel="noreferrer" aria-label={`Falar sobre ${area.title}`}>Conversar <ArrowRight /></a></div></article> })}</div></div></section>

    <section className="team-section container" id="equipe"><div className="section-title centered"><span className="eyebrow">QUEM ESTARÁ AO SEU LADO</span><h2>Atendimento <em>responsável</em></h2><p>Apresentação do profissional responsável pelo atendimento.</p></div><div className="team-grid">{site.team.map(person => <article key={person.name}><div className="portrait" style={person.image ? { backgroundImage: `url(${person.image})` } : undefined}><div><small>{person.role} · {person.oab}</small><h3>{person.name}</h3><span>{person.area}</span></div></div></article>)}</div></section>

    <section className="contact-section whatsapp-contact" id="contato"><div className="container whatsapp-contact-inner"><div><span className="eyebrow light">ATENDIMENTO DIRETO</span><h2>Converse com nossa equipe pelo WhatsApp.</h2><p>Conte brevemente sua necessidade. O contato é confidencial e responderemos dentro do horário de atendimento.</p><div className="contact-list">{site.contact.phone && <a href={`tel:+${site.contact.phone}`}><Phone /> {site.contact.phoneLabel}</a>}{site.contact.email && <a href={`mailto:${site.contact.email}`}><Mail /> {site.contact.email}</a>}</div></div><div className="whatsapp-panel"><MessageCircle /><span>RESPOSTA PERSONALIZADA</span><h3>Como podemos ajudar?</h3><p>Ao clicar, uma conversa será aberta com uma mensagem inicial pronta. Você poderá editá-la antes de enviar.</p><a className="button whatsapp-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Iniciar conversa <ArrowRight /></a><small>O envio da mensagem não estabelece automaticamente uma relação advogado-cliente.</small></div></div></section>

    <section className="faq-section" id="duvidas"><div className="container faq-grid"><div><span className="eyebrow">DÚVIDAS FREQUENTES</span><h2>Informação clara desde o primeiro contato.</h2><p>Reunimos respostas para as principais dúvidas sobre o atendimento.</p></div><div className="faq-list">{site.faqs.map((faq, index) => <details key={faq.question}><summary><span>0{index + 1}</span>{faq.question}<i>+</i></summary><p>{faq.answer}</p></details>)}</div></div></section>

    <section className="location-section" id="localizacao"><div className="container location-grid"><div className="location-copy"><span className="eyebrow">ONDE ESTAMOS</span><h2>Uma localização central para receber você.</h2><p>Nosso escritório tem fácil acesso por transporte público e estacionamentos na região.</p><div className="location-details"><span><MapPin /><span><small>ENDEREÇO</small>{site.office.address}<br />{site.office.district}</span></span><span><Clock3 /><span><small>ATENDIMENTO</small>{site.office.hours}<br />{site.office.appointment}</span></span></div><a className="location-link" href={mapsUrl} target="_blank" rel="noreferrer">Abrir rota no Google Maps <ArrowRight /></a></div><div className="map-frame"><iframe title={`Localização do escritório ${site.brand.name}`} src={mapsEmbed} loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div></div></section>

    <a className="whatsapp-float" href={whatsappUrl()} target="_blank" rel="noreferrer" aria-label="Conversar pelo WhatsApp"><MessageCircle /><span>Fale pelo WhatsApp</span></a>
  </>;
}
