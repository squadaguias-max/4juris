import { displayName, phoneLabel, projectData, projectWhatsappUrl, whatsappDigits } from "./project.data";

// Os valores centrais vêm de landing.data.json. O conteúdo abaixo funciona como complemento visual do template.
export const templateConfig = {
  brand: {
    name: displayName,
    descriptor: projectData.professional.officeName ? projectData.professional.name : "Advocacia",
    oab: projectData.professional.oab,
    eyebrow: `${projectData.professional.area} · ${projectData.location.city}`.toUpperCase(),
    headline: projectData.hero.title || projectData.professional.area,
    headlineAccent: projectData.hero.cta,
    description: projectData.hero.description,
  },
  contact: {
    whatsapp: projectData.contact.whatsapp,
    whatsappLabel: phoneLabel,
    whatsappMessage: projectData.contact.whatsappMessage,
    phone: whatsappDigits,
    phoneLabel,
    email: projectData.contact.email,
  },
  office: {
    address: "Av. Paulista, 1000 · 12º andar",
    district: "Bela Vista · São Paulo — SP",
    hours: "Segunda a sexta, das 9h às 18h",
    appointment: "Atendimento presencial com horário marcado",
    mapsQuery: "Av. Paulista, 1000, São Paulo",
    years: "15",
    description: "Com mais de 15 anos de atuação, reunimos conhecimento profundo e atendimento verdadeiramente próximo. Cada caso é conduzido com estratégia própria, transparência e responsabilidade.",
  },
  metrics: [],
  specialties: [
    { icon: "building", title: "Direito Empresarial", summary: "Apoio jurídico para decisões seguras e crescimento sustentável.", services: ["Contratos empresariais", "Sociedades e reorganizações", "Prevenção de riscos"], message: "Gostaria de falar sobre Direito Empresarial." },
    { icon: "scale", title: "Contencioso Estratégico", summary: "Defesa técnica em disputas complexas, com visão de resultado e longo prazo.", services: ["Ações cíveis", "Negociação e acordos", "Recursos e tribunais"], message: "Gostaria de falar sobre Contencioso Estratégico." },
    { icon: "users", title: "Família e Sucessões", summary: "Orientação sensível para proteger relações, patrimônio e o futuro da família.", services: ["Divórcio e guarda", "Inventário e partilha", "Planejamento sucessório"], message: "Gostaria de falar sobre Família e Sucessões." },
    { icon: "briefcase", title: "Direito do Trabalho", summary: "Atuação preventiva e contenciosa para empresas e profissionais.", services: ["Consultoria trabalhista", "Defesas e reclamações", "Acordos e compliance"], message: "Gostaria de falar sobre Direito do Trabalho." },
    { icon: "landmark", title: "Direito Tributário", summary: "Estratégias para reduzir riscos e solucionar questões fiscais.", services: ["Planejamento tributário", "Defesas administrativas", "Execuções fiscais"], message: "Gostaria de falar sobre Direito Tributário." },
    { icon: "file", title: "Contratos", summary: "Instrumentos claros e seguros, alinhados aos seus objetivos.", services: ["Elaboração e revisão", "Negociação contratual", "Análise de riscos"], message: "Gostaria de falar sobre Contratos." },
  ],
  team: [],
  faqs: [
    { question: "Como funciona a primeira conversa?", answer: "O contato inicial serve para entendermos sua necessidade e verificarmos como podemos ajudar. Caso seja necessário aprofundar a análise, explicaremos os próximos passos com transparência." },
    { question: "O atendimento pode ser on-line?", answer: "Sim. Atendemos por videoconferência em todo o Brasil, além do atendimento presencial em São Paulo com horário marcado." },
    { question: "Quais documentos devo separar?", answer: "Depende da área e do caso. Na primeira conversa, indicaremos os documentos mais relevantes para uma análise segura, evitando solicitações desnecessárias." },
    { question: "Como são definidos os honorários?", answer: "Os honorários consideram a complexidade, o escopo e o tempo estimado de atuação. Antes de qualquer contratação, você receberá uma proposta clara e detalhada." },
    { question: "O envio de mensagem já cria uma relação advogado-cliente?", answer: "Não. A relação profissional começa somente após a análise de viabilidade, alinhamento das condições e formalização da contratação." },
  ],
};

Object.assign(templateConfig.brand, {
  name: displayName,
  descriptor: projectData.professional.officeName ? projectData.professional.name : "Advocacia",
  oab: projectData.professional.oab,
  eyebrow: `${projectData.professional.area} · ${projectData.location.city}`.toUpperCase(),
  headline: projectData.hero.title || projectData.professional.area,
  headlineAccent: projectData.hero.cta,
  description: projectData.hero.description,
});
Object.assign(templateConfig.contact, {
  whatsapp: projectData.contact.whatsapp,
  whatsappLabel: phoneLabel,
  whatsappMessage: projectData.contact.whatsappMessage,
  phone: whatsappDigits,
  phoneLabel,
  email: projectData.contact.email,
});
Object.assign(templateConfig.office, {
  address: projectData.location.address || projectData.location.city,
  district: projectData.location.regions,
  hours: projectData.location.hours || "Atendimento mediante agendamento",
  mapsQuery: projectData.location.mapsQuery || projectData.location.city,
  description: projectData.professional.biography || projectData.hero.description,
});
templateConfig.specialties = projectData.services.map((service) => ({
  icon: "scale",
  title: service.title,
  summary: service.description,
  services: [],
  message: `Gostaria de falar sobre ${service.title}.`,
}));
templateConfig.team = [{
  name: projectData.professional.name,
  role: projectData.professional.officeName ? projectData.professional.officeName : "Advocacia",
  area: projectData.professional.area,
  oab: projectData.professional.oab,
  image: "",
}];

export function whatsappUrl(message = templateConfig.contact.whatsappMessage) {
  return projectWhatsappUrl(message);
}
