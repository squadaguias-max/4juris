import { Menu, X } from "lucide-react";
import { useState } from "react";
import { whatsappUrl } from "../../config/template.config";
import logo from "../../assets/logo.png";

function Link({ to, ...props }) {
  return <a href={to === "/" ? "#inicio" : to} {...props} />;
}

export function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return <header className="site-header"><div className="container header-inner"><Link className="brand" to="/" aria-label="Página inicial"><img className="brand-logo" src={logo} alt="Logo" /></Link><button className="menu-button" onClick={() => setOpen(!open)} aria-label={open ? "Fechar menu" : "Abrir menu"}>{open ? <X /> : <Menu />}</button><nav className={open ? "nav open" : "nav"}><a href="#inicio" onClick={close}>Início</a><a href="#experiencia" onClick={close}>Escritório</a><a href="#atuacao" onClick={close}>Atuação</a><a href="#equipe" onClick={close}>Equipe</a><a href="#duvidas" onClick={close}>Dúvidas</a><a href="#localizacao" onClick={close}>Localização</a><a className="nav-cta" href={whatsappUrl()} target="_blank" rel="noreferrer" onClick={close}>WhatsApp <span aria-hidden="true">↗</span></a></nav></div></header>;
}
