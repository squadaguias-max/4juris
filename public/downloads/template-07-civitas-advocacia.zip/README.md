# Civitas Advocacia

Template 07 da biblioteca 4Juris.

## Executar

```bash
npm install
npm run dev
```

Personalize todos os textos, contatos e dados demonstrativos antes de publicar.
