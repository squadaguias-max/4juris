Adicione nesta pasta as imagens, logotipos e demais mídias autorizadas do cliente.
