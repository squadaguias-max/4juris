import { createElement } from "react";
import { AlarmClock, ArrowRight, BriefcaseBusiness, Building2, Check, Clock3, GraduationCap, HeartPulse, Home, Mail, MapPin, Phone, Play, Scale, ShieldCheck, UsersRound } from "lucide-react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const defaultPractices = [
  [BriefcaseBusiness, "Direito Empresarial", "Estruturação, contratos e decisões estratégicas para empresas."],
  [HeartPulse, "Direito da Saúde", "Orientação para profissionais, clínicas e pacientes."],
  [Home, "Direito Imobiliário", "Negócios, contratos, regularização e proteção patrimonial."],
  [GraduationCap, "Direito Educacional", "Consultoria para instituições, famílias e profissionais."],
  [ShieldCheck, "Direito Criminal", "Defesa técnica, diligente e responsável em todas as etapas."],
];

const benefits = ["Processo claro e respeito ao seu tempo", "Estratégias construídas para cada contexto", "Comunicação direta com a equipe responsável"];

const faqs = [
  ["Como funciona a primeira consulta?", "A primeira conversa é destinada a compreender sua necessidade, identificar os pontos principais e orientar os próximos passos."],
  ["O atendimento pode ser realizado on-line?", "Sim. Atendemos por videoconferência em todo o Brasil e presencialmente em São Paulo com horário marcado."],
  ["Quais documentos preciso apresentar?", "Após o contato inicial, indicaremos somente os documentos necessários para a análise do seu caso."],
  ["Como são definidos os honorários?", "A proposta considera o escopo, a complexidade e o tempo estimado de atuação, sempre apresentada antes da contratação."],
];

export function HomePage() {
  const serviceIcons = [BriefcaseBusiness, HeartPulse, Home, GraduationCap, ShieldCheck];
  const practices = site.services?.length
    ? site.services.map((service, index) => [serviceIcons[index % serviceIcons.length], service.title, service.description])
    : defaultPractices;
  function maskPhone(event) {
    const digits = event.currentTarget.value.replace(/\D/g, "").slice(0, 11);
    event.currentTarget.value = digits.replace(/^(\d{0,2})(\d{0,5})(\d{0,4}).*/, (_, ddd, prefix, suffix) => [ddd && `(${ddd}`, ddd.length === 2 ? ") " : "", prefix, suffix && `-${suffix}`].join(""));
  }

  function schedule(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const message = `Olá! Gostaria de agendar uma conversa.\nNome: ${data.get("nome")}\nTelefone: ${data.get("telefone")}\nAssunto: ${data.get("assunto")}\nMensagem: ${data.get("mensagem")}`;
    window.open(whatsappUrl(message), "_blank", "noopener,noreferrer");
  }
  const mapQuery = encodeURIComponent(site.office.mapsQuery);
  return <>
    <section className="classic-hero" id="inicio"><div className="hero-overlay" /><div className="container hero-grid"><div className="hero-copy"><span className="gold-label">{site.brand.tagline}</span><h1>{site.hero.title}</h1><p>{site.hero.description}</p><a href="#escritorio">Conheça o escritório <ArrowRight /></a></div><form className="appointment-card" onSubmit={schedule}><span>Agende uma conversa</span><h2>Como podemos ajudar?</h2><label>Nome<input name="nome" required placeholder="Seu nome completo" /></label><label>Telefone<input name="telefone" required type="tel" inputMode="numeric" autoComplete="tel" minLength={14} maxLength={15} pattern={"\\(\\d{2}\\) \\d{4,5}-\\d{4}"} onInput={maskPhone} placeholder="(00) 00000-0000" /></label><label>Assunto<select name="assunto" required defaultValue=""><option value="" disabled>Selecione uma área</option>{practices.map(([, title]) => <option key={title}>{title}</option>)}</select></label><label>Mensagem<textarea name="mensagem" rows="3" placeholder="Conte-nos brevemente sua necessidade" /></label><button type="submit">Solicitar atendimento <ArrowRight /></button><small>Você será direcionado ao WhatsApp.</small></form></div></section>

    <section className="info-strip"><div className="container"><div><AlarmClock /><span><small>ATENDIMENTO</small>{site.office.hours}</span></div><div><Phone /><span><small>TELEFONE</small>{site.contact.phoneLabel}</span></div>{site.contact.email && <div><Mail /><span><small>E-MAIL</small>{site.contact.email}</span></div>}</div></section>

    <section className="intro-section" id="escritorio"><div className="pattern" /><div className="container"><div className="center-title"><span className="gold-label">SOBRE O ESCRITÓRIO</span><h2>Advocacia confiável para decisões importantes.</h2><p>Tradição jurídica, visão contemporânea e atendimento verdadeiramente próximo.</p></div><div className="editorial-image"><div className="play-button"><Play /></div></div><div className="practice-row">{practices.map(([Icon, title]) => <a href="#contato" key={title}>{createElement(Icon)}<span>{title}</span></a>)}</div><p className="practice-note">Precisa de orientação? <a href="#contato">Agende uma conversa com nossa equipe.</a></p></div></section>

    <section className="best-section"><div className="container best-grid"><div className="best-photo" role="img" aria-label="Profissionais reunidos no escritório" /><div className="best-copy"><span className="gold-label">NOSSOS DIFERENCIAIS</span><h2>Por que escolher a Aurea?</h2><p>Reunimos conhecimento técnico, organização e atenção aos detalhes para oferecer uma experiência segura desde o primeiro contato.</p><div className="benefit-list">{benefits.map((benefit, index) => <div key={benefit}><span>0{index + 1}</span><p>{benefit}</p><Check /></div>)}</div><a className="gold-button" href="#contato">Converse conosco <ArrowRight /></a></div></div></section>

    <section className="values-section"><div className="container values-grid"><article><Scale /><span>01</span><h3>Rigor técnico</h3><p>Análise cuidadosa e estratégia fundamentada para cada decisão.</p></article><article><UsersRound /><span>02</span><h3>Atendimento próximo</h3><p>Escuta, clareza e comunicação direta em todas as etapas.</p></article><article><Building2 /><span>03</span><h3>Visão de longo prazo</h3><p>Soluções que consideram riscos, oportunidades e objetivos futuros.</p></article></div></section>

    <section className="classic-faq" id="faq"><div className="container faq-grid"><div><span className="gold-label">DÚVIDAS FREQUENTES</span><h2>Informação clara desde o início.</h2><p>Encontre respostas sobre o funcionamento do atendimento.</p></div><div className="faq-list">{faqs.map(([question, answer], index) => <details key={question}><summary><span>0{index + 1}</span>{question}<i>+</i></summary><p>{answer}</p></details>)}</div></div></section>

    <section className="classic-contact" id="contato"><div className="container contact-inner"><div><span className="gold-label">PRIMEIRO PASSO</span><h2>Vamos conversar sobre o seu caso?</h2><p>O contato inicial é confidencial e não estabelece automaticamente uma relação advogado-cliente.</p></div><a className="gold-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Iniciar conversa <ArrowRight /></a></div></section>

    <section className="classic-location" id="localizacao"><div className="container location-grid"><div className="location-copy"><span className="gold-label">LOCALIZAÇÃO</span><h2>Estamos prontos para receber você.</h2><p>Nosso escritório possui localização central, fácil acesso por transporte público e atendimento presencial com horário marcado.</p><div><span><MapPin /><span><small>ENDEREÇO</small>{site.office.address}<br />{site.office.district}</span></span><span><Clock3 /><span><small>ATENDIMENTO</small>{site.office.hours}</span></span></div><a href={`https://www.google.com/maps/search/?api=1&query=${mapQuery}`} target="_blank" rel="noreferrer">Abrir rota no Google Maps <ArrowRight /></a></div><div className="map-frame"><iframe title={`Localização da ${site.brand.name} ${site.brand.descriptor}`} src={`https://www.google.com/maps?q=${mapQuery}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div></div></section>
  </>;
}
