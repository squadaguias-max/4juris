import { displayName, phoneLabel, projectData, projectWhatsappUrl, whatsappDigits } from "./project.data";

export const templateConfig = {
  brand: { name: displayName, descriptor: "Advocacia", oab: projectData.professional.oab, tagline: projectData.professional.area },
  hero: projectData.hero,
  contact: { whatsapp: projectData.contact.whatsapp, phone: whatsappDigits, phoneLabel, email: projectData.contact.email },
  office: { address: "Av. Paulista, 1000 · 12º andar", district: "Bela Vista · São Paulo — SP", hours: "Segunda a sexta, das 9h às 18h", mapsQuery: "Av. Paulista, 1000, São Paulo" },
};

Object.assign(templateConfig.brand, {
  name: displayName,
  descriptor: projectData.professional.officeName ? projectData.professional.name : "Advocacia",
  oab: projectData.professional.oab,
  tagline: projectData.professional.area,
});
Object.assign(templateConfig.hero, projectData.hero);
Object.assign(templateConfig.contact, {
  whatsapp: projectData.contact.whatsapp,
  phone: whatsappDigits,
  phoneLabel,
  email: projectData.contact.email,
});
Object.assign(templateConfig.office, {
  address: projectData.location.address || projectData.location.city,
  district: projectData.location.regions,
  hours: projectData.location.hours || "Atendimento mediante agendamento",
  mapsQuery: projectData.location.mapsQuery || projectData.location.city,
});
templateConfig.services = projectData.services;

export function whatsappUrl(message = projectData.contact.whatsappMessage) {
  return projectWhatsappUrl(message);
}
