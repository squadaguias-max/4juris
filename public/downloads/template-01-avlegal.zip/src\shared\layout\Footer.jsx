import logo from "../../assets/logo.png";
import { templateConfig as site } from "../../config/template.config";

export function Footer() {
  return <footer><div className="container footer-grid"><div className="footer-logo"><img className="footer-brand-logo" src={logo} alt={`Logo de ${site.displayName}`} /><p>Estratégia jurídica, clareza e responsabilidade.</p><span>{site.professional.oab}</span></div><div><b>NAVEGAÇÃO</b><a href="#atuacao">Serviços</a><a href="#escritorio">Sobre</a><a href="#faq">FAQ</a></div><div><b>CONTATO</b>{site.contact.phone && <a href={`tel:+${site.contact.phone}`}>{site.phoneLabel}</a>}{site.contact.email && <a href={`mailto:${site.contact.email}`}>{site.contact.email}</a>}</div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} {site.displayName}.</span><span>Este material tem caráter meramente informativo e não constitui publicidade profissional nos termos do Provimento nº 205/2021 do CFOAB. As informações aqui veiculadas não garantem resultados específicos.</span></div><a className="developed-by" href="https://somos4juris.com.br/" target="_blank" rel="noopener noreferrer">Desenvolvido por 4Juris</a></footer>;
}
