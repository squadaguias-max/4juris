import { ArrowRight, ArrowUpRight, Clock3, Mail, MapPin, Phone, Scale } from "lucide-react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const defaultServices = [
  { title: "Direito Empresarial", text: "Consultoria preventiva, contratos societários e suporte estratégico para decisões de negócio." },
  { title: "Contratos", text: "Elaboração, revisão e negociação de instrumentos claros, seguros e alinhados aos seus objetivos." },
  { title: "Família e Sucessões", text: "Orientação cuidadosa em divórcios, inventários, guarda e planejamento sucessório." },
  { title: "Contencioso Cível", text: "Defesa técnica em disputas complexas, com estratégia orientada à proteção de patrimônio e reputação." },
  { title: "Direito do Trabalho", text: "Atuação consultiva e contenciosa para empresas e profissionais, com foco em prevenção." },
  { title: "Direito Tributário", text: "Planejamento, revisão de passivos e defesa em processos administrativos e judiciais." },
];

const faqs = [
  ["Como funciona a primeira conversa?", "O contato inicial serve para compreendermos sua necessidade e identificarmos os próximos passos. Quando necessário, indicaremos documentos para uma análise mais aprofundada."],
  ["O atendimento pode ser realizado on-line?", "Sim. Atendemos por videoconferência em todo o Brasil e presencialmente em São Paulo, mediante agendamento."],
  ["Quais documentos devo apresentar?", "Os documentos variam de acordo com cada situação. Após o primeiro contato, enviaremos uma orientação objetiva sobre o que será necessário."],
  ["Como são definidos os honorários?", "Os honorários consideram o escopo, a complexidade e o tempo estimado de atuação. Todas as condições são apresentadas com clareza antes da contratação."],
];

export function HomePage() {
  const services = site.services?.length
    ? site.services.map((service) => ({ title: service.title, text: service.description }))
    : defaultServices;
  const mapQuery = encodeURIComponent(site.location.mapsQuery || site.location.city);
  return <>
    <section className="mono-hero" id="inicio">
      <div className="mono-hero-overlay" />
      <div className="container pt-36 mono-hero-content"><span className="mono-kicker">{site.professional.area}</span><h1>{site.hero.title || site.professional.area}</h1><p>{site.hero.description}</p><a className="light-button" href="#contato">{site.hero.cta} <ArrowRight /></a></div>
      <div className="container hero-stats"><div><strong>{site.professional.oab}</strong><span>identificação profissional</span></div><div><strong>{site.location.city}</strong><span>localização principal</span></div><div><strong>{site.services.length}</strong><span>{site.services.length === 1 ? "serviço informado" : "serviços informados"}</span></div><div><strong>On-line</strong><span>{site.location.regions}</span></div></div>
    </section>

    <section className="mono-section services-section" id="atuacao"><div className="container"><div className="mono-heading"><div><span className="mono-kicker">COMO PODEMOS AJUDAR</span><h2>Serviços jurídicos</h2></div><p>Soluções construídas de acordo com o contexto e os objetivos de cada cliente.</p></div><div className="service-cards">{services.map((service, index) => <article key={service.title}><span>0{index + 1}</span><h3>{service.title}</h3><p>{service.text}</p><a href="#contato">Saiba mais <ArrowUpRight /></a></article>)}</div><a className="outline-button" href="#contato">Fale com nossa equipe <ArrowRight /></a></div></section>

    <section className="mono-section about-section" id="escritorio"><div className="container about-grid"><div className="about-photo" role="img" aria-label={`Apresentação de ${site.displayName}`} /><div className="about-copy"><span className="mono-kicker">SOBRE</span><h2>{site.displayName}</h2><p>{site.professional.biography || site.hero.description}</p><ul><li>Atendimento próximo e personalizado</li><li>Comunicação clara em todas as etapas</li><li>Sigilo e ética como princípios inegociáveis</li></ul><a className="light-button compact" href="#contato">Conheça nossa atuação <ArrowRight /></a></div></div></section>

    <section className="mono-section faq-section" id="faq"><div className="container faq-wrap"><span className="mono-kicker">DÚVIDAS FREQUENTES</span><h2>FAQ</h2><div className="faq-list">{faqs.map(([question, answer], index) => <details key={question}><summary><span>0{index + 1}</span>{question}<i>+</i></summary><p>{answer}</p></details>)}</div></div></section>

    <section className="mono-contact" id="contato"><div className="container contact-box"><div><span className="mono-kicker">PRIMEIRO PASSO</span><h2>Precisa de orientação jurídica?</h2><p>Conte brevemente como podemos ajudar. Nossa equipe responderá para compreender sua necessidade e apresentar os próximos passos.</p></div><div className="contact-actions"><a className="light-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Conversar pelo WhatsApp <ArrowUpRight /></a>{site.contact.phone && <a href={`tel:+${site.contact.phone}`}><Phone /> {site.phoneLabel}</a>}{site.contact.email && <a href={`mailto:${site.contact.email}`}><Mail /> {site.contact.email}</a>}<span><MapPin /> {site.location.address || site.location.city}</span></div></div></section>

    <section className="mono-location" id="localizacao"><div className="container location-grid"><div className="location-copy"><span className="mono-kicker">LOCALIZAÇÃO</span><h2>{site.location.city}</h2><p>{site.location.regions}</p><div className="location-info"><span><MapPin /><span><small>ENDEREÇO</small>{site.location.address || site.location.city}</span></span><span><Clock3 /><span><small>ATENDIMENTO</small>{site.location.hours || "Mediante agendamento"}</span></span></div><a className="outline-button" href={`https://www.google.com/maps/search/?api=1&query=${mapQuery}`} target="_blank" rel="noreferrer">Abrir rota no Google Maps <ArrowUpRight /></a></div><div className="location-map"><iframe title={`Localização de ${site.displayName}`} src={`https://www.google.com/maps?q=${mapQuery}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div></div></section>
  </>;
}
