import { Menu, X } from "lucide-react";
import { useState } from "react";
import logo from "../../assets/logo.png";
import { templateConfig as site } from "../../config/template.config";

function Link({ to, ...props }) {
  return <a href={to === "/" ? "#inicio" : to} {...props} />;
}

export function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return <header className="site-header"><div className="container header-inner"><Link className="brand" to="/" aria-label="Página inicial"><img className="brand-logo" src={logo} alt={`Logo de ${site.displayName}`} /></Link><button className="menu-button" onClick={() => setOpen(!open)} aria-label={open ? "Fechar menu" : "Abrir menu"}>{open ? <X /> : <Menu />}</button><nav className={open ? "nav open" : "nav"}><a href="#inicio" onClick={close}>Início</a><a href="#atuacao" onClick={close}>Serviços</a><a href="#escritorio" onClick={close}>Sobre</a><a href="#faq" onClick={close}>FAQ</a><a href="#localizacao" onClick={close}>Localização</a>{site.contact.phone && <a className="nav-phone" href={`tel:+${site.contact.phone}`}>{site.phoneLabel}</a>}<a className="light-button nav-button" href="#contato" onClick={close}>Fale conosco</a></nav></div></header>;
}
