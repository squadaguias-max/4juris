import { Menu, MessageCircle, X } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { whatsappUrl } from "../../config/template.config";

export function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return <header className="site-header"><div className="container header-inner"><Link className="brand" to="/" aria-label="Página inicial"><span className="brand-mark">L</span><b>Lume</b><small>ADVOCACIA</small></Link><button className="menu-button" onClick={() => setOpen(!open)} aria-label={open ? "Fechar menu" : "Abrir menu"}>{open ? <X /> : <Menu />}</button><nav className={open ? "nav open" : "nav"}><a href="#escritorio" onClick={close}>O escritório</a><a href="#atuacao" onClick={close}>Atuação</a><a href="#processo" onClick={close}>Como trabalhamos</a><a href="#diferenciais" onClick={close}>Diferenciais</a><a href="#localizacao" onClick={close}>Localização</a><a className="header-cta" href={whatsappUrl()} target="_blank" rel="noreferrer">Fale conosco <MessageCircle /></a></nav></div></header>;
}
