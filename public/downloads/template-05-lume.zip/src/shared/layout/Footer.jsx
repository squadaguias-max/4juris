import { Mail, MapPin, Phone } from "lucide-react";
import { templateConfig as site } from "../../config/template.config";

export function Footer() {
  return <footer><div className="container footer-inner"><div className="footer-brand"><span>L</span><h3>{site.brand.name}</h3><small>{site.brand.descriptor}</small></div><div className="footer-contacts"><a href={`tel:+${site.contact.phone}`}><Phone />{site.contact.phoneLabel}</a><a href={`mailto:${site.contact.email}`}><Mail />{site.contact.email}</a><span><MapPin />{site.office.district}</span></div><p>Conteúdo exclusivamente informativo, sem promessa de resultado. Cada situação depende de análise individual e das normas éticas aplicáveis.</p><a className="developed-by" href="https://somos4juris.com.br/" target="_blank" rel="noopener noreferrer">Desenvolvido por 4Juris</a></div></footer>;
}
