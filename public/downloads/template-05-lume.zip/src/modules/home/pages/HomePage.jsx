import { ArrowRight, Building2, Check, ChevronDown, Clock3, FileSearch, Handshake, MapPin, MessageCircle, Scale } from "lucide-react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const services = [
  { n: "01", title: "Direito Empresarial", text: "Assessoria preventiva e estratégica para decisões, contratos e relações societárias." },
  { n: "02", title: "Direito Civil", text: "Orientação clara para relações patrimoniais, obrigações e conflitos complexos." },
  { n: "03", title: "Planejamento Patrimonial", text: "Estruturas jurídicas para proteção, organização e continuidade do patrimônio." },
  { n: "04", title: "Contratos", text: "Elaboração e revisão de instrumentos alinhados aos riscos e objetivos do cliente." },
];
const faqs = [
  ["Como funciona o primeiro atendimento?", "A conversa inicial serve para compreender o contexto, identificar documentos relevantes e explicar os próximos passos possíveis."],
  ["O atendimento pode ser on-line?", "Sim. Atendemos por videoconferência em todo o Brasil, além das reuniões presenciais com horário marcado."],
  ["Quais documentos devo separar?", "A relação depende do assunto. Após o primeiro contato, indicamos apenas os documentos necessários para uma análise responsável."],
];

export function HomePage(){
  const query=encodeURIComponent(site.office.mapsQuery);
  return <>
    <section className="hero" id="inicio"><div className="hero-photo"/><div className="hero-shade"/><div className="container hero-content"><span className="eyebrow light">Advocacia estratégica e próxima</span><h1>Clareza para decidir.<br/><em>Segurança para avançar.</em></h1><p>Orientação jurídica cuidadosa para pessoas e empresas que valorizam relações transparentes, soluções consistentes e visão de longo prazo.</p><a className="button light-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Agendar uma conversa <ArrowRight/></a></div></section>

    <section className="intro" id="escritorio"><div className="container intro-grid"><aside><span className="mini-label">NOSSO ESCRITÓRIO<br/>EM NÚMEROS</span><strong>12+</strong><p>anos de experiência</p><strong>Atuação<br/>nacional</strong><p>atendimento presencial e on-line</p></aside><div className="intro-copy"><span className="eyebrow">O escritório</span><h2>Rigor técnico com uma forma mais humana de advogar.</h2><p>Na Lume, acreditamos que o trabalho jurídico começa pela escuta. Traduzimos cenários complexos em orientações objetivas, construindo estratégias sob medida para cada cliente.</p><p>Nossa atuação combina profundidade técnica, comunicação acessível e acompanhamento próximo em todas as etapas.</p><a className="text-link" href="#processo">Conheça nossa forma de trabalhar <ArrowRight/></a></div><div className="intro-photo" role="img" aria-label="Profissionais analisando documentos em uma mesa"/></div></section>

    <section className="services" id="atuacao"><div className="container"><header className="section-title"><span className="eyebrow">Áreas de atuação</span><h2>Soluções jurídicas pensadas<br/>para cada contexto.</h2></header><div className="service-stack">{services.map(({n,title,text})=><article key={title}><span>{n}</span><Scale/><div><h3>{title}</h3><p>{text}</p></div><ArrowRight/></article>)}</div></div></section>

    <section className="process" id="processo"><div className="container"><header className="section-title center"><span className="eyebrow">Como trabalhamos</span><h2>Uma jornada simples, transparente e cuidadosa.</h2></header><div className="process-grid"><article><span>01</span><MessageCircle/><h3>Escuta e contexto</h3><p>Começamos entendendo sua realidade, prioridades e expectativas.</p></article><article><span>02</span><FileSearch/><h3>Análise estratégica</h3><p>Avaliamos documentos, riscos e caminhos juridicamente adequados.</p></article><article><span>03</span><Handshake/><h3>Plano e acompanhamento</h3><p>Apresentamos os próximos passos com clareza e seguimos ao seu lado.</p></article></div></div></section>

    <section className="benefits" id="diferenciais"><div className="container"><header className="section-title"><span className="eyebrow">Por que escolher a Lume</span><h2>Confiança construída nos detalhes.</h2></header><div className="benefit-layout"><div className="benefit-cards"><article><Check/><h3>Atendimento próximo</h3><p>Comunicação direta, respeitosa e sem juridiquês desnecessário.</p></article><article><Check/><h3>Estratégia personalizada</h3><p>Cada orientação considera o seu contexto, não respostas prontas.</p></article><article className="wide"><Check/><h3>Compromisso com a excelência</h3><p>Estudo cuidadoso, atualização constante e atuação responsável.</p></article></div><div className="benefit-photo"><div><Building2/><span>VISÃO DE LONGO PRAZO</span><h3>Direito como instrumento de boas decisões.</h3></div></div></div></div></section>

    <section className="lawyer"><div className="container lawyer-grid"><div className="lawyer-photo"/><div><span className="eyebrow">À frente do escritório</span><h2>{site.brand.lawyer}</h2><strong>{site.brand.oab}</strong><p>Advogada com experiência consultiva e contenciosa, dedicada a transformar questões jurídicas complexas em decisões compreensíveis e seguras.</p><p>Sua prática une técnica, sensibilidade e visão estratégica, com participação próxima em cada atendimento.</p><a className="button dark-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Falar com a advogada <ArrowRight/></a></div></div></section>

    <section className="faq" id="faq"><div className="container faq-grid"><header className="section-title"><span className="eyebrow">Perguntas frequentes</span><h2>Antes de começar,<br/>algumas respostas.</h2></header><div>{faqs.map(([q,a])=><details key={q}><summary>{q}<ChevronDown/></summary><p>{a}</p></details>)}</div></div></section>

    <section className="contact"><div className="container"><span className="eyebrow light">Vamos conversar?</span><h2>Boas decisões começam<br/>com uma orientação clara.</h2><p>Conte brevemente o que você precisa. Nossa equipe responderá para organizar o primeiro atendimento.</p><a className="button light-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Iniciar conversa no WhatsApp <MessageCircle/></a></div></section>

    <section className="location" id="localizacao"><div className="container location-grid"><div><span className="eyebrow">Localização</span><h2>Atendimento presencial e on-line.</h2><p>Recebemos clientes com horário marcado e atendemos por videoconferência em todo o Brasil.</p><div className="location-item"><MapPin/><span><small>ENDEREÇO</small>{site.office.address}<br/>{site.office.district}</span></div><div className="location-item"><Clock3/><span><small>ATENDIMENTO</small>{site.office.hours}</span></div><a className="text-link" href={`https://www.google.com/maps/search/?api=1&query=${query}`} target="_blank" rel="noreferrer">Abrir rota no Google Maps <ArrowRight/></a></div><div className="map-frame"><iframe title={`Localização de ${site.brand.name}`} src={`https://www.google.com/maps?q=${query}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade"/></div></div></section>
    <a className="floating-whatsapp" href={whatsappUrl()} target="_blank" rel="noreferrer" aria-label="Falar no WhatsApp"><MessageCircle/></a>
  </>;
}
