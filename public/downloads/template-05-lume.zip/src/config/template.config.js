export const templateConfig = {
  brand: { name: "Lume", descriptor: "Advocacia estratégica", lawyer: "Dra. Marina Lemos", oab: "OAB/SP 000.000" },
  contact: { whatsapp: "5511999999999", phone: "551130001200", phoneLabel: "(11) 3000-1200", email: "contato@lume.adv.br" },
  office: { address: "Alameda Santos, 1200 · 8º andar", district: "Jardins · São Paulo — SP", hours: "Segunda a sexta, das 9h às 18h", mapsQuery: "Alameda Santos, 1200, São Paulo" },
};

export function whatsappUrl(message = "Olá! Gostaria de agendar uma conversa sobre meu caso.") {
  return `https://wa.me/${templateConfig.contact.whatsapp}?text=${encodeURIComponent(message)}`;
}
