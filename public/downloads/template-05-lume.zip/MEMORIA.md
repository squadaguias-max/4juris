# Memória — Template 5

## Conceito
Landing page para advocacia boutique. Direção visual orgânica e sofisticada, inspirada na referência fornecida: superfícies marfim, areia e café; bordas amplas; fotografia de interiores; títulos Manrope e textos DM Sans.

## Regras permanentes
- Navbar fixa em cápsula e menu responsivo.
- Localização com mapa no final, antes do rodapé.
- Botão flutuante de WhatsApp.
- Dados centrais em `src/config/template.config.js`.
- Textos informativos, sem promessa de resultado.
- Imagens externas são demonstrativas e devem ser substituídas no projeto final.
