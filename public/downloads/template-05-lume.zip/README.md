# Template 5 — Advocacia Boutique

Landing page jurídica premium inspirada em interiores contemporâneos: marfim, areia, café, cartões arredondados e fotografia editorial. A composição valoriza clareza, proximidade e atuação estratégica.

## Personalização

Edite `src/config/template.config.js` para alterar marca, profissional, OAB, contatos, endereço, horário e mapa. Edite `src/modules/home/pages/HomePage.jsx` para adaptar áreas, textos, processo e perguntas frequentes.

## Estrutura

- navbar fixa e menu móvel;
- hero editorial;
- apresentação e indicadores;
- áreas de atuação em cartões empilhados;
- processo em três etapas;
- diferenciais;
- perfil profissional;
- FAQ;
- WhatsApp;
- localização com mapa antes do rodapé.

## Executar

```bash
npm install
npm run dev
```

Substitua dados, métricas e fotografias demonstrativas antes da publicação.
