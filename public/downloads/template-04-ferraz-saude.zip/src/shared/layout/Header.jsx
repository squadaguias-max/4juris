import { Menu, MessageCircle, X } from "lucide-react";
import { useState } from "react";
import { whatsappUrl } from "../../config/template.config";
import logo from "../../assets/logo.png";

function Link({ to, ...props }) {
  return <a href={to === "/" ? "#inicio" : to} {...props} />;
}

export function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return <header className="site-header"><div className="container header-inner"><Link className="brand" to="/" aria-label="Página inicial"><img className="brand-logo" src={logo} alt="Logo" /></Link><button className="menu-button" onClick={() => setOpen(!open)} aria-label={open ? "Fechar menu" : "Abrir menu"}>{open ? <X /> : <Menu />}</button><nav className={open ? "nav open" : "nav"}><a href="#situacoes" onClick={close}>Situações</a><a href="#atuacao" onClick={close}>Atuação</a><a href="#processo" onClick={close}>Como funciona</a><a href="#profissional" onClick={close}>Profissional</a><a href="#faq" onClick={close}>FAQ</a><a href="#localizacao" onClick={close}>Localização</a><a className="header-cta" href={whatsappUrl()} target="_blank" rel="noreferrer"><MessageCircle /> WhatsApp</a></nav></div></header>;
}
