import { Mail, MapPin, Phone } from "lucide-react";
import { templateConfig as site } from "../../config/template.config";
import logo from "../../assets/logo.png";

export function Footer() {
  return <footer><div className="container footer-inner"><img className="footer-brand-logo" src={logo} alt="Logo" /><h3>{site.brand.name}</h3><strong>{site.brand.descriptor} · {site.brand.oab}</strong><div>{site.contact.phone && <a href={`tel:+${site.contact.phone}`}><Phone />{site.contact.phoneLabel}</a>}{site.contact.email && <a href={`mailto:${site.contact.email}`}><Mail />{site.contact.email}</a>}<span><MapPin />{site.office.district}</span></div><p>Este material tem caráter meramente informativo e não constitui publicidade profissional nos termos do Provimento nº 205/2021 do CFOAB. As informações aqui veiculadas não garantem resultados específicos.</p><a className="developed-by" href="https://somos4juris.com.br/" target="_blank" rel="noopener noreferrer">Desenvolvido por 4Juris</a></div></footer>;
}
