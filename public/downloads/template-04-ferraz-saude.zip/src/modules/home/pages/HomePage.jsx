import { ArrowRight, Check, Clock3, FileCheck2, Mail, MapPin, MessageCircle, Phone, Scale, Send, ShieldCheck, Stethoscope, UserRound } from "lucide-react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const situations = ["Medicamento negado", "Cirurgia ou internação recusada", "Exame ou terapia sem cobertura", "Home Care ou tratamento pelo SUS negado"];
const defaultAreas = ["Medicamentos", "Cirurgias", "Exames e internações", "Terapias", "Home Care", "Tratamentos oncológicos"];
const faqs = [
  ["Meu plano negou o tratamento. Ainda posso buscar orientação?", "Sim. Cada negativa possui características próprias e pode ser analisada juridicamente conforme a documentação médica e contratual."],
  ["O SUS não fornece o medicamento prescrito. O que posso fazer?", "É possível analisar quais medidas podem ser adequadas considerando a prescrição, os laudos e a legislação aplicável."],
  ["Preciso ter a negativa por escrito?", "Sempre que possível, esse documento ajuda na análise. Caso você ainda não o tenha, podemos orientar sobre como solicitar."],
  ["Quais documentos são importantes?", "Normalmente são avaliados documentos pessoais, prescrição, laudos, exames, relatório médico e a negativa do plano ou do SUS."],
];

export function HomePage(){
  const query=encodeURIComponent(site.office.mapsQuery);
  const areas=site.services?.length ? site.services.map((service)=>service.title) : defaultAreas;
  return <>
    <section className="health-hero" id="inicio"><div className="hero-grid-pattern"/><Scale className="hero-scale" strokeWidth={.7}/><div className="container hero-content"><span className="eyebrow">{site.professional.area}</span><h1>{site.hero.title}</h1><p>{site.hero.description}</p><a className="primary-button" href={whatsappUrl()} target="_blank" rel="noreferrer">{site.hero.cta} <ArrowRight/></a></div></section>

    <section className="light-section cases-section" id="situacoes"><div className="container"><header className="section-heading"><span className="eyebrow">Seu caso</span><h2>Isso aconteceu com você?</h2></header><div className="situation-grid">{situations.map(item=><div key={item}><span><Check/></span><p>{item}</p></div>)}</div><div className="center"><a className="primary-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Analisar meu caso <ArrowRight/></a></div></div></section>

    <section className="dark-section expertise-section" id="atuacao"><div className="container"><header className="section-heading"><span className="eyebrow">Atuação especializada</span><h2>Como podemos ajudar</h2></header><div className="area-grid">{areas.map(area=><article key={area}><Check/><p>{area}</p></article>)}</div></div></section>

    <section className="urgency-section"><div className="container urgency-inner"><span className="eyebrow">Não perca tempo</span><h2>Em muitos casos, o tempo faz diferença.</h2><p>Quando um medicamento, cirurgia ou tratamento é negado, o atraso pode comprometer a continuidade do atendimento indicado pelo médico.</p><p>Buscar orientação quanto antes permite organizar a documentação e compreender os caminhos possíveis.</p><a className="primary-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Conversar com a equipe <ArrowRight/></a></div></section>

    <section className="light-section process-section" id="processo"><div className="container"><header className="section-heading"><span className="eyebrow">Processo simples e transparente</span><h2>Como funciona?</h2></header><div className="steps"><article><span>1</span><MessageCircle/><h3>Entre em contato</h3><p>Conte sua situação à nossa equipe pelo WhatsApp.</p></article><article><span>2</span><FileCheck2/><h3>Envie os documentos</h3><p>Organizamos prescrição, laudos, exames e a negativa.</p></article><article><span>3</span><ShieldCheck/><h3>Receba orientação</h3><p>Avaliamos o caso e explicamos as possibilidades jurídicas.</p></article></div></div></section>

    <section className="dark-section why-section"><div className="container"><header className="section-heading"><span className="eyebrow">Diferenciais</span><h2>Atendimento técnico e humanizado.</h2></header><div className="why-grid"><div><Check/>Análise individual de cada caso</div><div><Check/>Comunicação clara durante o atendimento</div><div><Check/>Atuação dedicada ao Direito da Saúde</div><div><Check/>Acompanhamento em todas as etapas</div></div></div></section>

    <section className="light-section about-section" id="profissional"><div className="container about-grid"><div className="lawyer-photo"><UserRound/><span>Foto profissional</span></div><div><span className="eyebrow">Quem estará ao seu lado</span><h2>{site.brand.lawyer}</h2><strong>{site.brand.oab}</strong><p>{site.professional.biography || site.hero.description}</p><p>O compromisso é oferecer orientação ética, transparente e personalizada, respeitando as particularidades de cada caso.</p><a className="outline-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Falar com a especialista <Send/></a></div></div></section>

    <section className="faq-section" id="faq"><div className="container faq-wrap"><header className="section-heading"><span className="eyebrow">Tire suas dúvidas</span><h2>Perguntas frequentes</h2></header>{faqs.map(([question,answer],index)=><details key={question}><summary><span>0{index+1}</span>{question}<i>+</i></summary><p>{answer}</p></details>)}</div></section>

    <section className="final-cta" id="contato"><div className="container"><span className="eyebrow">Fale conosco agora</span><h2>Não adie a análise do seu caso.</h2><p>Converse com nossa equipe e entenda quais possibilidades jurídicas podem existir para a sua situação.</p><a className="primary-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Falar com uma especialista <MessageCircle/></a></div></section>

    <section className="location-section" id="localizacao"><div className="container location-grid"><div><span className="eyebrow">Localização</span><h2>Atendimento presencial e on-line.</h2><p>Recebemos clientes com horário marcado e também atendemos por videoconferência em todo o Brasil.</p><div className="location-details"><span><MapPin/><span><small>ENDEREÇO</small>{site.office.address}<br/>{site.office.district}</span></span><span><Clock3/><span><small>ATENDIMENTO</small>{site.office.hours}</span></span></div><a href={`https://www.google.com/maps/search/?api=1&query=${query}`} target="_blank" rel="noreferrer">Abrir rota no Google Maps <ArrowRight/></a></div><div className="map-frame"><iframe title={`Localização de ${site.brand.name}`} src={`https://www.google.com/maps?q=${query}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade"/></div></div></section>

    <a className="floating-whatsapp" href={whatsappUrl()} target="_blank" rel="noreferrer" aria-label="Falar no WhatsApp"><MessageCircle/></a>
  </>;
}
