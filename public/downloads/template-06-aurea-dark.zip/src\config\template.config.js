export const templateConfig = {
  brand: { name: "Aurea", descriptor: "Advocacia estratégica", lawyer: "Dra. Helena Duarte", oab: "OAB/SP 000.000" },
  contact: { whatsapp: "5511999999999", phone: "551130001200", phoneLabel: "(11) 3000-1200", email: "contato@aurea.adv.br" },
  office: { address: "Avenida Exemplo, 1000 · 8º andar", district: "São Paulo · SP", hours: "Segunda a sexta, das 9h às 18h", mapsQuery: "São Paulo, SP" },
};

export function whatsappUrl(message = "Olá! Gostaria de agendar uma conversa sobre meu caso.") {
  return `https://wa.me/${templateConfig.contact.whatsapp}?text=${encodeURIComponent(message)}`;
}
