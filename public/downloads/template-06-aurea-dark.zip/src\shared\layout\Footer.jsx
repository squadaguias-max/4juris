import { Mail, MapPin, Phone } from "lucide-react";
import { templateConfig as site } from "../../config/template.config";

export function Footer() {
  return <footer><div className="container footer-grid"><div className="footer-brand"><span>A</span><div><h3>{site.brand.name}</h3><small>{site.brand.descriptor}</small></div></div><div><h4>Navegação</h4><a href="#escritorio">O escritório</a><a href="#atuacao">Áreas de atuação</a><a href="#processo">Como funciona</a><a href="#faq">Perguntas frequentes</a></div><div><h4>Contato</h4><a href={`tel:+${site.contact.phone}`}><Phone />{site.contact.phoneLabel}</a><a href={`mailto:${site.contact.email}`}><Mail />{site.contact.email}</a><span><MapPin />{site.office.district}</span></div></div><div className="container footer-bottom"><p>Este material tem caráter meramente informativo e não constitui publicidade profissional nos termos do Provimento nº 205/2021 do CFOAB. As informações aqui veiculadas não garantem resultados específicos. Cada caso depende de análise individual.</p><a href="https://somos4juris.com.br/" target="_blank" rel="noopener noreferrer">Desenvolvido por 4Juris</a></div></footer>;
}
