import {
  ArrowRight, BadgeDollarSign, BookOpen, BriefcaseBusiness, Building2,
  CheckCircle2, ChevronDown, CircleUserRound, FileCheck2, Gavel,
  GraduationCap, Handshake, HeartHandshake, Landmark, Mail, MapPin,
  MessageCircle, Phone, Scale, ShieldCheck, UsersRound,
} from "lucide-react";
import { createElement } from "react";
import { templateConfig as site, whatsappUrl } from "../../../config/template.config";

const highlights = [
  { icon: HeartHandshake, title: "Atendimento próximo", text: "Escuta cuidadosa, comunicação direta e acompanhamento em cada etapa do seu caso." },
  { icon: CheckCircle2, title: "Estratégia responsável", text: "Análise individual e caminhos jurídicos explicados com clareza, sem promessas de resultado." },
  { icon: ShieldCheck, title: "Segurança e transparência", text: "Informações objetivas para que você compreenda riscos, possibilidades e próximos passos." },
];

const practiceAreas = [
  { icon: CircleUserRound, title: "Direito Previdenciário", text: "Benefícios, aposentadorias e planejamento previdenciário." },
  { icon: GraduationCap, title: "Direito Educacional", text: "Orientação para alunos, famílias e instituições de ensino." },
  { icon: FileCheck2, title: "Direito Securitário", text: "Análise de apólices, coberturas e relações com seguradoras." },
  { icon: BriefcaseBusiness, title: "Direito Empresarial", text: "Prevenção de riscos e suporte às decisões da empresa." },
  { icon: Building2, title: "Direito Imobiliário", text: "Contratos, regularização e questões relacionadas a imóveis." },
  { icon: Gavel, title: "Direito Criminal", text: "Defesa técnica e atuação cuidadosa em todas as fases." },
  { icon: Landmark, title: "Direito Trabalhista", text: "Consultoria e representação em relações de trabalho." },
  { icon: UsersRound, title: "Direito de Família", text: "Soluções sensíveis para vínculos familiares e patrimônio." },
];

const faqs = [
  ["Como funciona o primeiro atendimento?", "A conversa inicial é dedicada a compreender o contexto, organizar as informações e indicar os próximos passos possíveis."],
  ["O atendimento pode ser feito on-line?", "Sim. O escritório realiza atendimentos por videoconferência, além de reuniões presenciais previamente agendadas."],
  ["Quais documentos preciso enviar?", "Os documentos variam conforme o caso. Após o primeiro contato, você receberá uma orientação objetiva sobre o que é necessário."],
];

export function HomePage() {
  return <>
    <section className="hero" id="inicio">
      <div className="hero-bg" /><div className="hero-overlay" /><div className="hero-art hero-art-one" /><div className="hero-art hero-art-two" />
      <div className="container hero-content">
        <span className="eyebrow light">Advocacia ética e estratégica</span>
        <h1>Seu direito merece<br /><em>atenção, estratégia</em><br />e voz.</h1>
        <p>Atuação jurídica responsável para transformar situações complexas em caminhos claros, seguros e possíveis.</p>
        <div className="hero-actions"><a className="button gold-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Agendar uma conversa <ArrowRight /></a><a className="button ghost-button" href="#atuacao">Conhecer Áreas de atuação</a></div>
        <div className="hero-contact"><span><MapPin />{site.office.district}</span><a href={`tel:+${site.contact.phone}`}><Phone />{site.contact.phoneLabel}</a><a href={`mailto:${site.contact.email}`}><Mail />{site.contact.email}</a></div>
      </div>
      <div className="hero-person" role="img" aria-label="Advogada do escritório" />
    </section>

    <section className="highlight-wrap" aria-label="Diferenciais"><div className="container highlight-grid">{highlights.map(({ icon: Icon, title, text }) => <article key={title}><span className="round-icon">{createElement(Icon)}</span><h3>{title}</h3><p>{text}</p></article>)}</div></section>

    <section className="trust"><div className="container trust-row"><span>ATUAÇÃO COM</span><b>ÉTICA</b><b>CLAREZA</b><b>PROXIMIDADE</b><b>ESTRATÉGIA</b><b>RESPONSABILIDADE</b></div></section>

    <section className="about" id="escritorio"><div className="container about-grid">
      <div className="about-copy"><span className="eyebrow">Sobre o escritório</span><h2>Direito não precisa ser distante para ser sério.</h2><p>Acreditamos em uma advocacia que une conhecimento técnico, escuta genuína e comunicação acessível. Cada questão é analisada com cuidado, considerando a realidade e os objetivos de quem nos procura.</p><a className="text-link" href="#contato">Conheça nossa forma de atender <ArrowRight /></a></div>
      <div className="about-person" role="img" aria-label="Profissional do escritório" /><div className="about-shape" />
      <div className="about-copy right"><span className="eyebrow">Por que nos escolher</span><h2>Tempo e atenção para compreender o que realmente importa.</h2><p>Sem respostas prontas ou soluções genéricas. A estratégia é construída de forma individual, transparente e alinhada às normas éticas da advocacia.</p><a className="text-link" href="#processo">Veja como trabalhamos <ArrowRight /></a></div>
    </div></section>

    <section className="quote-band" id="contato"><div className="container quote-box"><div><span className="eyebrow light">Fale com nossa equipe</span><h2>Solicite um primeiro contato</h2></div><form onSubmit={(event) => event.preventDefault()}><label><span>Nome</span><input required placeholder="Como podemos chamar você?" /></label><label><span>E-mail</span><input type="email" required placeholder="voce@email.com" /></label><label><span>Assunto</span><select defaultValue=""><option value="" disabled>Selecione uma área</option>{practiceAreas.map((area) => <option key={area.title}>{area.title}</option>)}</select></label><button className="button ink-button" type="submit">Enviar solicitação <ArrowRight /></button></form><small>Ao enviar, você concorda em ser contatado para tratar exclusivamente desta solicitação.</small></div></section>

    <section className="practice" id="atuacao"><div className="practice-overlay" /><div className="container practice-content"><header className="section-heading light-heading"><div><span className="eyebrow light">Áreas de atuação</span><h2>Experiência para orientar<br />decisões importantes.</h2></div><a className="text-link light-link" href={whatsappUrl()} target="_blank" rel="noreferrer">Converse com a equipe <ArrowRight /></a></header><div className="practice-grid">{practiceAreas.map(({ icon: Icon, title, text }) => <article key={title}><span className="round-icon">{createElement(Icon)}</span><h3>{title}</h3><p>{text}</p><ArrowRight className="area-arrow" /></article>)}</div></div></section>

    <section className="process" id="processo"><div className="container"><header className="section-heading"><div><span className="eyebrow">Como funciona</span><h2>Um atendimento claro<br />do início ao próximo passo.</h2></div></header><div className="process-grid"><article><b>01</b><MessageCircle /><h3>Primeiro contato</h3><p>Você apresenta brevemente sua situação e combinamos o melhor formato de atendimento.</p></article><article><b>02</b><BookOpen /><h3>Análise individual</h3><p>O contexto e os documentos são estudados com atenção para identificar caminhos possíveis.</p></article><article><b>03</b><Scale /><h3>Estratégia e orientação</h3><p>Você recebe uma explicação clara sobre riscos, alternativas e os próximos passos.</p></article><article><b>04</b><Handshake /><h3>Acompanhamento</h3><p>Se houver contratação, cada etapa é conduzida com transparência e comunicação próxima.</p></article></div></div></section>

    <section className="lawyer"><div className="container lawyer-grid"><div className="lawyer-photo" /><div><span className="eyebrow">À frente do escritório</span><h2>{site.brand.lawyer}</h2><strong>{site.brand.oab}</strong><p>Uma atuação comprometida com o estudo constante, a responsabilidade profissional e a construção de relações baseadas em confiança.</p><p>Todos os atendimentos são conduzidos de maneira individual, respeitando a singularidade de cada situação e os limites éticos da profissão.</p><a className="button ink-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Falar com a advogada <ArrowRight /></a></div></div></section>

    <section className="faq" id="faq"><div className="container faq-grid"><header><span className="eyebrow">Perguntas frequentes</span><h2>Informação também é uma forma de cuidado.</h2></header><div>{faqs.map(([question, answer]) => <details key={question}><summary>{question}<ChevronDown /></summary><p>{answer}</p></details>)}</div></div></section>

    <section className="final-cta"><div className="container"><BadgeDollarSign /><span className="eyebrow light">Atendimento individual</span><h2>Precisa de orientação jurídica?</h2><p>Conte brevemente sua situação e saiba como podemos ajudar.</p><a className="button gold-button" href={whatsappUrl()} target="_blank" rel="noreferrer">Iniciar conversa <ArrowRight /></a></div></section>
    <a className="floating-whatsapp" href={whatsappUrl()} target="_blank" rel="noreferrer" aria-label="Falar pelo WhatsApp"><MessageCircle /></a>
  </>;
}
