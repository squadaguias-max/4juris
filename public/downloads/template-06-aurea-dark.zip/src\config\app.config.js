import { defaultBrand } from "./brand.config";
export const appConfig={name:"Aurea Advocacia",description:"Orientação jurídica estratégica, ética e próxima.",brand:defaultBrand,features:{catalog:false,account:false,admin:false},navigation:[{label:"Início",to:"#inicio"},{label:"O escritório",to:"#escritorio"},{label:"Áreas de atuação",to:"#atuacao"},{label:"Como funciona",to:"#processo"}]};
